<!DOCTYPE html>
<!-- db_error.php -->
<html>
    <!-- the head section -->
    <head>
        <title>Error</title>
    </head>

    <!-- the body section -->
    <body>
    <main>
        <h1>Database Error</h1>
        <p>There was an error connecting to the database.</p>
    </main>
    </body>
</html>
